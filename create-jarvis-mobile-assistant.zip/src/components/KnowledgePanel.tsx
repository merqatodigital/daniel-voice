"use client";

import { useState } from "react";
import type { KnowledgeItem } from "@/lib/clientTypes";

type Props = {
  items: KnowledgeItem[];
  reload: () => Promise<void>;
};

const input =
  "w-full rounded-xl border border-cyan-400/20 bg-slate-950/60 px-3 py-2.5 text-sm text-slate-100 outline-none placeholder:text-slate-600 focus:border-cyan-400/60";

export default function KnowledgePanel({ items, reload }: Props) {
  const [mode, setMode] = useState<"single" | "bulk">("single");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [bulk, setBulk] = useState("");
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState<number | null>(null);

  const add = async () => {
    setBusy(true);
    const payload = mode === "bulk" ? { bulk, tags } : { title, content, tags };
    const res = await fetch("/api/knowledge", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setBusy(false);
    if (res.ok) {
      setTitle("");
      setContent("");
      setBulk("");
      await reload();
    }
  };

  const remove = async (id: number) => {
    await fetch(`/api/knowledge?id=${id}`, { method: "DELETE" });
    await reload();
  };

  const filtered = items.filter((k) =>
    query
      ? `${k.title} ${k.tags} ${k.content}`.toLowerCase().includes(query.toLowerCase())
      : true,
  );

  return (
    <div className="space-y-5 pb-28">
      <section className="glass rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold tracking-wide text-cyan-200 hud-text">Teach your assistant</h2>
          <div className="flex rounded-lg border border-slate-700/70 p-0.5 text-[11px]">
            {(["single", "bulk"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-md px-2 py-1 capitalize ${mode === m ? "bg-cyan-500/20 text-cyan-200" : "text-slate-400"}`}
              >
                {m === "single" ? "Entry" : "Paste doc"}
              </button>
            ))}
          </div>
        </div>

        {mode === "single" ? (
          <>
            <input
              className={input}
              placeholder="Title — e.g. My morning routine"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <textarea
              className={`${input} h-32 resize-none`}
              placeholder="Facts, preferences, procedures, people, passwords hints, project context…"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </>
        ) : (
          <textarea
            className={`${input} h-44 resize-none`}
            placeholder={"Paste a whole document. It will be split into entries at markdown headings (# Heading) or blank-line breaks."}
            value={bulk}
            onChange={(e) => setBulk(e.target.value)}
          />
        )}

        <input
          className={input}
          placeholder="Tags (comma separated)"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
        />
        <button
          onClick={add}
          disabled={busy || (mode === "single" ? !title || !content : !bulk.trim())}
          className="w-full rounded-xl bg-cyan-500 py-3 text-sm font-semibold text-slate-950 disabled:opacity-40"
        >
          {busy ? "Storing…" : mode === "single" ? "Add to knowledge base" : "Import document"}
        </button>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold tracking-wide text-cyan-200 hud-text">
            Knowledge base · {items.length}
          </h2>
        </div>
        <input
          className={input}
          placeholder="Search entries…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {filtered.length === 0 && (
          <p className="rounded-xl border border-dashed border-slate-700/60 p-6 text-center text-sm text-slate-500">
            Nothing stored yet. Anything you add here is what your assistant treats as truth.
          </p>
        )}
        {filtered.map((k) => (
          <article key={k.id} className="glass rounded-2xl p-4">
            <div className="flex items-start justify-between gap-3">
              <button className="text-left" onClick={() => setOpen(open === k.id ? null : k.id)}>
                <h3 className="text-sm font-medium text-slate-100">{k.title}</h3>
                <p className={`mt-1 text-xs text-slate-400 ${open === k.id ? "" : "line-clamp-2"} whitespace-pre-wrap`}>
                  {k.content}
                </p>
              </button>
              <button onClick={() => remove(k.id)} className="shrink-0 text-xs text-rose-400/80">
                delete
              </button>
            </div>
            {k.tags ? (
              <div className="mt-2 flex flex-wrap gap-1">
                {k.tags.split(",").filter(Boolean).map((t) => (
                  <span key={t} className="rounded-full bg-cyan-500/10 px-2 py-0.5 text-[10px] text-cyan-200">
                    {t.trim()}
                  </span>
                ))}
              </div>
            ) : null}
          </article>
        ))}
      </section>
    </div>
  );
}
