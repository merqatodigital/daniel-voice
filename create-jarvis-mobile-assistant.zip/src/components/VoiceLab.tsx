"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ENGINE_INFO,
  catalogFor,
  DEFAULT_VOICE,
  type CatalogVoice,
  type VoiceEngine,
} from "@/lib/tts/catalog";
import {
  piperStoredVoices,
  setKokoroDtype,
  speak,
  stopAudio,
  type TtsStatus,
} from "@/lib/tts/engine";
import { useVoices } from "@/lib/useSpeech";
import type { ClientSettings } from "@/lib/clientTypes";

type Props = {
  settings: ClientSettings;
  onChange: (patch: Partial<ClientSettings>) => void;
};

const ENGINES: VoiceEngine[] = ["system", "piper", "kokoro"];

const SAMPLE = (name: string) =>
  `Systems online. This is ${name}, your personal assistant. Everything you hear is generated on your device.`;

export default function VoiceLab({ settings, onChange }: Props) {
  const systemVoices = useVoices();
  const [genderFilter, setGenderFilter] = useState<"all" | "male" | "female">(
    settings.voiceGender === "female" ? "female" : "male",
  );
  const [langFilter, setLangFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [previewing, setPreviewing] = useState<string | null>(null);
  const [status, setStatus] = useState<TtsStatus>({ stage: "idle" });
  const [stored, setStored] = useState<string[]>([]);

  useEffect(() => {
    if (settings.voiceEngine === "piper") {
      piperStoredVoices().then(setStored);
    }
  }, [settings.voiceEngine, status.stage]);

  const engine: VoiceEngine = settings.voiceEngine;
  const info = ENGINE_INFO[engine];

  const languages = useMemo(() => {
    if (engine === "system") {
      return Array.from(new Set(systemVoices.map((v) => v.lang))).sort();
    }
    const set = new Map<string, string>();
    catalogFor(engine).forEach((v) => set.set(v.lang, v.langLabel));
    return Array.from(set.keys()).sort();
  }, [engine, systemVoices]);

  const list = useMemo((): CatalogVoice[] => {
    if (engine !== "system") {
      return catalogFor(engine).filter((v) => {
        if (genderFilter !== "all" && v.gender !== genderFilter) return false;
        if (langFilter !== "all" && v.lang !== langFilter) return false;
        if (query) {
          const hay = `${v.name} ${v.langLabel} ${v.accent ?? ""} ${v.note ?? ""} ${v.id}`.toLowerCase();
          if (!hay.includes(query.toLowerCase())) return false;
        }
        return true;
      });
    }
    return [] as CatalogVoice[];
  }, [engine, genderFilter, langFilter, query]);

  const systemList = useMemo(() => {
    if (engine !== "system") return [];
    return systemVoices.filter((v) => {
      if (genderFilter !== "all" && v.guessed !== genderFilter) return false;
      if (langFilter !== "all" && v.lang !== langFilter) return false;
      if (query && !v.name.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
  }, [engine, systemVoices, genderFilter, langFilter, query]);

  const preview = async (id: string, name: string) => {
    if (previewing) {
      stopAudio();
      setPreviewing(null);
      return;
    }
    setPreviewing(id);
    try {
      await speak({
        engine,
        voiceId: id,
        voiceURI: engine === "system" ? id : undefined,
        gender: settings.voiceGender,
        rate: settings.voiceRate,
        pitch: settings.voicePitch,
        text: SAMPLE(name),
        onStatus: setStatus,
      });
    } finally {
      setPreviewing(null);
      setStatus({ stage: "idle" });
    }
  };

  const busy = status.stage === "loading" || previewing !== null;

  return (
    <section className="glass rounded-2xl p-4 space-y-4">
      <div>
        <h2 className="text-sm font-semibold tracking-wide text-cyan-200 hud-text">Voice engine</h2>
        <p className="mt-0.5 text-[11px] text-slate-500">
          All three are free and open source. Audio is generated on your device — nothing is sent to a server.
        </p>
      </div>

      <div className="space-y-2">
        {ENGINES.map((e) => {
          const i = ENGINE_INFO[e];
          const on = engine === e;
          return (
            <button
              key={e}
              onClick={() =>
                onChange({
                  voiceEngine: e,
                  voiceId: e === "system" ? "" : settings.voiceId || DEFAULT_VOICE[e],
                })
              }
              className={`w-full rounded-xl border p-3 text-left transition ${
                on ? "border-cyan-400/70 bg-cyan-400/10" : "border-slate-700/60 bg-slate-950/40"
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium text-slate-100">
                  {i.emoji} {i.label}
                </span>
                <span className="shrink-0 rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-300">
                  {i.download}
                </span>
              </div>
              <p className="mt-1 text-[11px] leading-snug text-slate-400">{i.blurb}</p>
              <p className="mt-1 text-[10px] uppercase tracking-wider text-emerald-400/80">{i.license}</p>
            </button>
          );
        })}
      </div>

      {engine === "kokoro" && (
        <div className="rounded-xl border border-slate-700/60 bg-slate-950/40 p-3">
          <p className="text-[11px] uppercase tracking-[0.18em] text-cyan-300/80">Model precision</p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            {(["q8", "fp32"] as const).map((d) => (
              <button
                key={d}
                onClick={() => {
                  setKokoroDtype(d);
                  onChange({ kokoroDtype: d });
                }}
                className={`rounded-lg border px-2 py-2 text-left text-[11px] ${
                  settings.kokoroDtype === d
                    ? "border-cyan-400/70 bg-cyan-400/10 text-cyan-100"
                    : "border-slate-700/60 text-slate-400"
                }`}
              >
                <span className="block text-[12px] font-medium">
                  {d === "q8" ? "q8 · Fast" : "fp32 · Best"}
                </span>
                <span className="text-[10px] text-slate-500">
                  {d === "q8" ? "86 MB, quick on phones" : "326 MB, richest audio"}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="space-y-2 border-t border-slate-700/50 pt-3">
        <div className="flex gap-1.5">
          {(["all", "male", "female"] as const).map((g) => (
            <button
              key={g}
              onClick={() => setGenderFilter(g)}
              className={`flex-1 rounded-lg border px-2 py-1.5 text-[11px] capitalize ${
                genderFilter === g
                  ? "border-cyan-400/60 bg-cyan-400/10 text-cyan-100"
                  : "border-slate-700/60 text-slate-400"
              }`}
            >
              {g === "all" ? "All" : g === "male" ? "♂ Male" : "♀ Female"}
            </button>
          ))}
        </div>
        <div className="flex gap-1.5">
          <select
            value={langFilter}
            onChange={(e) => setLangFilter(e.target.value)}
            className="w-40 rounded-lg border border-cyan-400/20 bg-slate-950/70 px-2 py-1.5 text-[11px] text-slate-200 outline-none"
          >
            <option value="all">All languages</option>
            {languages.map((l) => (
              <option key={l} value={l}>
                {engine === "system"
                  ? l
                  : (catalogFor(engine).find((v) => v.lang === l)?.langLabel ?? l)}
              </option>
            ))}
          </select>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search voices…"
            className="flex-1 rounded-lg border border-cyan-400/20 bg-slate-950/70 px-2 py-1.5 text-[11px] text-slate-200 outline-none placeholder:text-slate-600"
          />
        </div>
      </div>

      {/* Progress */}
      {status.stage === "loading" && (
        <div className="rounded-xl border border-cyan-400/30 bg-cyan-400/5 p-3">
          <p className="text-[11px] text-cyan-100">{status.label}</p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full rounded-full bg-cyan-400 transition-all"
              style={{ width: `${status.pct ?? 12}%` }}
            />
          </div>
          <p className="mt-1 text-[10px] text-slate-500">
            {status.pct !== undefined ? `${status.pct}%` : "working…"} — cached offline afterwards
          </p>
        </div>
      )}
      {status.stage === "error" && (
        <p className="rounded-xl border border-amber-400/40 bg-amber-400/10 p-2.5 text-[11px] text-amber-200">
          {status.message}
        </p>
      )}

      {/* Voice gallery */}
      {engine === "system" ? (
        <div className="max-h-72 space-y-1.5 overflow-y-auto pr-1">
          {systemVoices.length === 0 && (
            <p className="py-6 text-center text-[11px] text-slate-500">No device voices detected yet…</p>
          )}
          <VoiceRow
            id=""
            name="Auto (pick best match)"
            sub="Recommended"
            selected={!settings.voiceURI}
            previewing={false}
            onPreview={() => preview("", "Auto")}
            onSelect={() => onChange({ voiceURI: "" })}
          />
          {systemList.map((v) => (
            <VoiceRow
              key={v.uri}
              id={v.uri}
              name={v.name}
              sub={`${v.lang} · ${v.guessed}`}
              selected={settings.voiceURI === v.uri}
              previewing={previewing === v.uri}
              onPreview={() => preview(v.uri, v.name)}
              onSelect={() => onChange({ voiceURI: v.uri })}
            />
          ))}
        </div>
      ) : (
        <div className="max-h-80 space-y-1.5 overflow-y-auto pr-1">
          <p className="text-[10px] uppercase tracking-widest text-slate-500">
            {list.length} open-source voices
          </p>
          {list.map((v) => (
            <VoiceRow
              key={v.id}
              id={v.id}
              name={v.name}
              sub={`${v.langLabel}${v.accent ? ` · ${v.accent}` : ""}${v.note ? ` · ${v.note}` : ""}`}
              selected={settings.voiceId === v.id}
              previewing={previewing === v.id}
              downloaded={engine === "piper" ? stored.includes(v.id) : undefined}
              onPreview={() => preview(v.id, v.name)}
              onSelect={() => onChange({ voiceId: v.id, voiceGender: v.gender })}
            />
          ))}
          {list.length === 0 && (
            <p className="py-6 text-center text-[11px] text-slate-500">No voices match those filters.</p>
          )}
        </div>
      )}

      {/* Delivery controls */}
      <div className="space-y-3 border-t border-slate-700/50 pt-3">
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.18em] text-cyan-300/80">
            Speed — {settings.voiceRate}%
          </span>
          <input
            type="range"
            min={60}
            max={160}
            value={settings.voiceRate}
            onChange={(e) => onChange({ voiceRate: Number(e.target.value) })}
            className="mt-1.5 w-full accent-cyan-400"
          />
        </label>
        <label className="block">
          <span className="text-[11px] uppercase tracking-[0.18em] text-cyan-300/80">
            Pitch — {settings.voicePitch}%
          </span>
          <input
            type="range"
            min={50}
            max={160}
            value={settings.voicePitch}
            onChange={(e) => onChange({ voicePitch: Number(e.target.value) })}
            className="mt-1.5 w-full accent-cyan-400"
          />
          <p className="mt-1 text-[10px] text-slate-500">
            {engine === "system"
              ? "Pitch applies to device voices."
              : "Pitch is fixed in the neural model; speed still applies."}
          </p>
        </label>

        <div className="flex items-center justify-between rounded-xl border border-slate-700/60 bg-slate-950/40 px-3 py-3">
          <span className="text-sm text-slate-200">Speak replies aloud</span>
          <button
            onClick={() => onChange({ speakReplies: !settings.speakReplies })}
            className={`h-7 w-12 rounded-full transition ${settings.speakReplies ? "bg-cyan-500" : "bg-slate-700"}`}
          >
            <span
              className={`block h-6 w-6 translate-x-0.5 rounded-full bg-white transition ${
                settings.speakReplies ? "translate-x-[22px]" : ""
              }`}
            />
          </button>
        </div>

        <button
          disabled={busy}
          onClick={() =>
            preview(
              engine === "system" ? settings.voiceURI : settings.voiceId || DEFAULT_VOICE[engine],
              settings.agentName,
            )
          }
          className="w-full rounded-xl border border-cyan-400/40 bg-cyan-400/10 py-2.5 text-sm font-medium text-cyan-100 disabled:opacity-50"
        >
          {busy ? "Generating…" : "▶ Test this voice"}
        </button>

        <p className="text-[10px] leading-relaxed text-slate-500">
          {info.emoji} {info.label} — {info.license}. First use downloads the model; after that it runs
          fully offline from your browser cache.
        </p>
      </div>
    </section>
  );
}

function VoiceRow({
  id,
  name,
  sub,
  selected,
  previewing,
  downloaded,
  onPreview,
  onSelect,
}: {
  id: string;
  name: string;
  sub: string;
  selected: boolean;
  previewing: boolean;
  downloaded?: boolean;
  onPreview: () => void;
  onSelect: () => void;
}) {
  return (
    <div
      className={`flex items-center gap-2 rounded-xl border px-3 py-2 transition ${
        selected ? "border-cyan-400/60 bg-cyan-400/10" : "border-slate-700/50 bg-slate-950/30"
      }`}
    >
      <button onClick={onPreview} className="shrink-0 text-cyan-300" aria-label={`Preview ${name}`}>
        {previewing ? "■" : "▶"}
      </button>
      <button onClick={onSelect} className="min-w-0 flex-1 text-left">
        <div className="truncate text-[13px] text-slate-100">{name}</div>
        <div className="truncate text-[10px] text-slate-500">
          {sub}
          {downloaded === true ? " · ↓ cached" : downloaded === false ? "" : ""}
        </div>
      </button>
      {selected && <span className="text-[10px] text-cyan-300">✓</span>}
    </div>
  );
}
