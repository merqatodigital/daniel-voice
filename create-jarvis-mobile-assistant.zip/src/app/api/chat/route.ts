import { NextResponse } from "next/server";
import { db } from "@/db";
import { messages, tasks, knowledge } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSettings, getKnowledge, getTasks, getMessages } from "@/lib/store";
import { localBrain, llmBrain, type AgentContext } from "@/lib/agent";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ messages: await getMessages() });
}

export async function DELETE() {
  await db.delete(messages);
  return NextResponse.json({ ok: true });
}

export async function POST(req: Request) {
  const body = (await req.json()) as { input?: string };
  const input = (body.input ?? "").trim();
  if (!input) return NextResponse.json({ error: "empty input" }, { status: 400 });

  const [settings, kb, taskRows, history] = await Promise.all([
    getSettings(),
    getKnowledge(),
    getTasks(),
    getMessages(20),
  ]);

  const ctx: AgentContext = {
    settings,
    knowledge: kb,
    tasks: taskRows,
    history: history.map((m) => ({ role: m.role, content: m.content })),
  };

  // Local brain first — it handles commands deterministically (tasks, memory,
  // maths, briefings). If it draws a blank, escalate to an LLM when available.
  let result = localBrain(input, ctx);
  const localWasWeak =
    result.actions.length === 0 && result.usedKnowledge.length === 0;
  if (localWasWeak) {
    const llm = await llmBrain(input, ctx);
    if (llm) result = llm;
  }

  for (const action of result.actions) {
    if (action.type === "create_task") {
      await db.insert(tasks).values({ title: action.title.slice(0, 200) });
    } else if (action.type === "complete_task") {
      await db.update(tasks).set({ done: true }).where(eq(tasks.id, action.id));
    } else if (action.type === "create_knowledge") {
      await db.insert(knowledge).values({
        title: action.title.slice(0, 160),
        content: action.content,
        source: "conversation",
      });
    }
  }

  await db.insert(messages).values([
    { role: "user", content: input },
    {
      role: "agent",
      content: result.reply,
      meta: { engine: result.engine, usedKnowledge: result.usedKnowledge },
    },
  ]);

  return NextResponse.json({
    reply: result.reply,
    engine: result.engine,
    usedKnowledge: result.usedKnowledge,
    tasks: await getTasks(),
  });
}
