import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "JARVIS — Personal Assistant",
  description: "Your voice-driven daily AI assistant with a custom knowledge base and attitude.",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "JARVIS" },
};

export const viewport: Viewport = {
  themeColor: "#04070d",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh text-slate-100 antialiased selection:bg-cyan-400/30">
        {children}
      </body>
    </html>
  );
}
